<?php include "top_include.php"; ?>

        <main class = "box">
            
            <h2>Lake Tekapo</h2>
            
            <p>Come and see the crystal clear lake and peaceful scenery at Lake Tekapo</p>
            
            </main>
        
        <aside class = "box">
        
            <h2>What are your thoughts?</h2>
            
            <?php include "poll_include.php"; ?>
            
            xmlhttp.open("GET","poll/lake_tekapo_poll.php?vote="+int,true);
                xmlhttp.send();
        
            <?php include "bottom_poll_include.php"; ?>
            
            <br>
            
            <img class="allround" src="img/lake_tekapo.jpg">
            
            </aside>
        
<?php include "bottom_include.php"; ?>      