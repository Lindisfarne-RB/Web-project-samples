<?php include "top_include.php"; ?>

        <main class = "box">
            
            <h2>Auckland</h2>
            
            <p>Enjoy our largest city! See the beautiful view from the skytower or go to the zoo, there's so much to do!</p>
            
            </main>
        
        <aside class = "box">
        
            <h2>What are your thoughts?</h2>
            
            <?php include "poll_include.php"; ?>
            
            xmlhttp.open("GET","poll/auckland_poll.php?vote="+int,true);
                xmlhttp.send();
        
            <?php include "bottom_poll_include.php"; ?> 
            
            <br>
            
            <img class="allround" src="img/auckland.jpg">
            
            </aside>
        
<?php include "bottom_include.php"; ?>      