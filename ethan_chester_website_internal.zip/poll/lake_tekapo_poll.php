<!-- customised from https://www.w3schools.com/php/php_ajax_poll.asp -->
<?php
$vote = $_REQUEST['vote'];

//get content of textfile
$filename = "lake_tekapo_result.txt";
$content = file($filename);

?>

<?php include "polling_include.php"; ?>