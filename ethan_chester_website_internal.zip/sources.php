<?php include "top_include.php"; ?>
<!-- includes the top_include file -->

        <main class = "box">
        <!-- sets up the main content area -->
            
            <h2>Sources</h2>
            <!-- main area content title in h2 font -->
            
            <p><a href="https://www.w3schools.com/css/css_dropdowns.asp">W3schools</a> dropdown code<br><a href="https://www.w3schools.com/php/php_ajax_poll.asp">W3schools</a> polling code<br>All images are pubic domain<br><a href="https://www.google.com/forms/about/">Google forms</a></p>
            <!-- main content with links to the sources -->
            
            </main>
            <!-- closes the main section -->
        
        <aside class = "box">
        <!-- sets up the side bar area -->
            
            </aside>
            <!-- closes the aside section -->
        
<?php include "bottom_include.php"; ?>      
<!-- includes the bottom_include file -->