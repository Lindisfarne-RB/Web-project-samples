            }
     </script>
     
     <div id="poll">
         <h3>Would you like to go here?</h3>
         <form>
                Yes: <input type="radio" name="vote" value="0" onclick="getVote(this.value)"><br>
                No: <input type="radio" name="vote" value="1" onclick="getVote(this.value)">
         </form>
     </div>