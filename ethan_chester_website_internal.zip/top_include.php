<!DOCTYPE html>
<html lang="en">
 
<head>
     
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-    scale=1">
    <meta name="description" content="Free Web tutorials">
    <meta name="keywords" content="HTML,CSS,XML,JavaScript">
    <meta name="author" content="John Doe"> 
     
    <title>Travel New Zealand</title> 
    <!-- names the page 'Tourism in New Zealand -->
     
    <link href="css/tourism_style.css" rel="stylesheet">
    <!-- links the css styling file -->

    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Syne+Mono&display=swap" rel="stylesheet">
    <!-- links the syne mono font for the header text -->
    
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300&display=swap" rel="stylesheet">
    <!-- links the inter font for the body text -->
    
    </head>
    
<body>
    
    <div class = "wrapper">
        
        <header class = "box">
            
            <h1>Travel New Zealand</h1>
            
            <a class="dropbtn" href="index.php">Home</a>
            
            <div class="dropdown">
                
                <a class="dropbtn" href="#">Locations<span class="littlearrow">&#9660;</span></a>
                
                <div class="dropdown-content">
                    
                    <a href="hobbiton.php">Hobbiton</a>
                    
                    <a href="lake_tekapo.php">Lake Tekapo</a>
                    
                    <a href="fox_glacier.php">Fox Glacier</a>   
                    
                    <a href="auckland.php">Auckland</a>
                    
                    </div>
                
                </div>
            
            <a class="dropbtn" href="sources.php">Sources</a>
            
            <a class="dropbtn" href="contact.php">Contact</a>  
            
            </header>
        
        <logo class = "box">
            
            <img class="padding" src="img/logo_v1.jpg" alt="landscape" width="176" height="140" />
            
            </logo>