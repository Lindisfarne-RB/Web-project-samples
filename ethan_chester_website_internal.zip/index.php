<?php include "top_include.php"; ?>

        <main class = "box">
            
            <h2>Home</h2>
            
            <p>New Zealand is a beautiful country to explore! This website will show you some of the best places to go!</p>
            
            <div class="homeimages">
            
            <div class="hobbiton">
                <a href="hobbiton.php"><img class="allround" src="img/hobbiton.jpg" alt="link to hobbiton page" width="300" height="190"></a>
            </div>
            <div class="lake_tekapo">
                <a href="lake_tekapo.php"><img class="allround" src="img/lake_tekapo.jpg" alt="link to lake_tekapo page" width="300" height="190"></a>
            </div>
            <div class="fox_glacier">
                <a href="fox_glacier.php"><img class="allround" src="img/fox_glacier.jpg" alt="link to fox_glacier page" width="300" height="190"></a>
            </div>
            <div class="auckland">
                <a href="auckland.php"><img class="allround" src="img/auckland.jpg" alt="link to auckland page" width="300" height="190"></a>
            </div>
        
        </div>
            
            </main>
        
        <aside class = "box">
        
            <h2>Our Goal</h2>
            
            <p>We aim to show you some beautiful locations in New Zealand to ensure your next trip will be everything it should be</p>
            
            </aside>
        
<?php include "bottom_include.php"; ?>      