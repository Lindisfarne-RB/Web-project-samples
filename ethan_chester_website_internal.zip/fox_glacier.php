<?php include "top_include.php"; ?>

        <main class = "box">
            
            <h2>Fox Glacier</h2>
            
            <p>Take a helicopter ride over the beautiful glaciers!</p>
            
            </main>
        
        <aside class = "box">
        
            <h2>What are your thoughts?</h2>
            
            <?php include "poll_include.php"; ?>
            
            xmlhttp.open("GET","poll/fox_glacier_poll.php?vote="+int,true);
                xmlhttp.send();
        
            <?php include "bottom_poll_include.php"; ?>   
            
            <br>
            
            <img class="allround" src="img/fox_glacier.jpg">
            
            </aside>
        
<?php include "bottom_include.php"; ?>      