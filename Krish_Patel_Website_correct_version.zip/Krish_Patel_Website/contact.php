<?php include "nav.php"; ?> <!-- linking php to get nav to in the contact us page --> 
	
		<main class="box"> <!-- getting google form embeded into the contact page -->
			
		<iframe src="https://docs.google.com/forms/d/e/1FAIpQLSf5vR8MPFOb40F6UnsP5FORaimGYXUuFRPuYYnC-TXyhxOCEw/viewform?embedded=true" width="640" height="1020" frameborder="0" marginheight="0" marginwidth="0">Loading…</iframe>

		</main>
		

		<aside class="box"> <!-- socails and contact information on the side. -->
		
			Instagarm : @kiwitourists<br>
			Facebook : Kiwi Tourists<br>
			E-Mail : help@kiwi.tourists.com<br>
			Phone Number : 095348693<br>
			Address : <br> 36 Alberton Avenue, Mount Albert, Auckland 1025
		</aside>
		


	<?php include "bot.php"; ?> <!-- getting the footer in to contact us page -->