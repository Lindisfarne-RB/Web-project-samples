<?php include "nav.php"; ?> <!-- linking php to get nav to in the sources page --> 

<main class="box">
			
			
			<h2>Sources</h2>
			
			<p> <!-- sources where i got infomaration from -->
				https://www.newzealand.com/<br>
				https://www.tourism.net.nz/<br>
				https://www.mbie.govt.nz/immigration-and-tourism/tourism/<br>
				https://en.wikipedia.org/wiki/Tourism_in_New_Zealand<br>
				https://www.southerndiscoveries.co.nz/latest/everything-you-should-know-about-lake-wakatipu/<br>
				
			</p>


</main>
		<!-- getting content on the side -->
		<aside class="box"> 
			<p>
				All websites listed are sourced legally.
				</p>
		</aside>
		

	<?php include "bot.php"; ?> <!-- getting the footer in to sources page -->