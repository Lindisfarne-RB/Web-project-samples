		<footer class="box"> <!-- footer starting --> 
			&copy; Krish Patel 2021
			
			<a href="https://www.instagram.com/"> <!-- insta socail --> 
         		<img alt="Insta" src="img/insta.png" width="25" style="float: left; padding-left: 10px;">
      		</a>
			<a href="https://www.facebook.com/"> <!-- facebook socail --> 
         		<img alt="Insta" src="img/facebook.png" width="25" style="float: left; padding-left: 10px;">
      		</a>
		</footer>
		
	</div>
</body>

</html> <!-- ending html page --> 