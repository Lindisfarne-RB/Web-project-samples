<?php include "topbit.php"; ?>
	<main class="box">
		<h2>Queenstown</h2>
		<!-- Slideshow -->
		<div class="slideshow-container">

			<!-- First image in slideshow -->
			<div class="mySlides fade">
				<div class="numbertext">1 / 3</div>
				<img src="img/queenstownsky.jpg" style="width:100%" alt="Queenstown sunset">
				<div class="text">Queenstown sunset</div>
			</div>
			
			<!-- Second image in slideshow -->
			<div class="mySlides fade">
				<div class="numbertext">2 / 3</div>
				<img src="img/queenstownmountains.jpg" style="width:100%" alt="Mountain view from Queenstown">
				<div class="text">Mountain view from Queenstown</div>
			</div>
			
			<!-- Third image in slideshow -->
			<div class="mySlides fade">
				<div class="numbertext">3 / 3</div>
				<img src="img/wakatipi.jpg" style="width:100%" alt="Lake Wakatipi">
				<div class="text">Lake Wakatipu</div>
			</div>

			<!-- Next and previous buttons -->
			<a class="prev" onclick="plusSlides(-1)">&#10094;</a>
			<a class="next" onclick="plusSlides(1)">&#10095;</a>
		</div>
		<br>

		<!-- The dots that show which image the slideshow is on -->
		<div style="text-align:center">
			<span class="dot" onclick="currentSlide(1)"></span>
			<span class="dot" onclick="currentSlide(2)"></span>
			<span class="dot" onclick="currentSlide(3)"></span>
		</div>
		<!-- Slideshow javascript -->
		<script src="slideshow.js"></script>
		
		<!-- Queenstown info. -->
		<p>Queenstown is a tourist town in the south island which is surrounded by mountains and lakes. It is a popular destination for anyone visiting New Zealand and for people that live in New Zealand. It has a lot of <a href="queenstownactivities.php">activities</a> to do and <a href="https://www.queenstownnz.co.nz/accommodation/">places</a> to stay. <br>
		For more information on Queenstown, visit <a href="https://www.queenstownnz.co.nz/">www.queenstownnz.co.nz</a>.</p>
	</main>
	<main-aside class="box">
		<!-- Links to Queenstown activities and where to stay in Queenstown -->
		<p>For activites to do in Queenstown, look <a href="queenstownactivities.php">here</a><br>
		For places to stay in Queenstown, look <a href="https://www.queenstownnz.co.nz/accommodation/">here</a></p>
		<!-- Queenstown poll javacript -->
		<script>
			function getVote(int) {
				var xmlhttp=new XMLHttpRequest();
				xmlhttp.onreadystatechange=function() {
					if (this.readyState==4 && this.status==200) {
						document.getElementById("poll").innerHTML=this.responseText;
    				}
  				}
  				xmlhttp.open("GET","polls/queenstownvote.php?vote="+int,true);
  				xmlhttp.send();
			}
		</script>
		<!-- queenstown poll html -->
		<div id="poll">
			<h4>Do you recommend visiting this location?</h4>
			<form>
				<!-- yes input -->
				Yes: <input type="radio" name="vote" value="0" onclick="getVote(this.value)"><br>
				<!-- no input -->
				No: <input type="radio" name="vote" value="1" onclick="getVote(this.value)">
			</form>
		</div>
	</main-aside>
<?php include "bottombit.php"; ?>