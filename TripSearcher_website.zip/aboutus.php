<?php include "topbit.php"; ?>
	<main class="box">
		<!-- About why the website was made -->
		<h3>About Us</h3>
		<a href="https://www.mags.school.nz/"><center><img src="img/MAGSlogo.jpg" alt="MAGS logo"></center></a>
		<p>TripSearcher is a fake company made for a school project at MAGS. It was supposedly made in the month of March in 2021, and has been a company for approximately 2 weeks and was made by a student named Owen Shaw. It is meant to be a company/website that helps tourists find places to go around NZ, and provide information on those places and where to stay at those places.
	</main>
	<main-aside class="box">
		<!-- Link to the school webpage if users want to find out more about MAGS and digitech -->
		<a href="https://www.mags.school.nz/">Here</a> is a link to the Mount Albert Grammar School Webpage.
	</main-aside>
<?php include "bottombit.php"; ?>