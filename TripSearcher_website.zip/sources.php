<?php include "topbit.php"; ?>
	<main class="box">
		<h2>Image Source</h2>
		<p>All images on this webpage were sourced from <a href="https://pixabay.com/">pixabay</a> and are in the public domain.</p>
		<h2>Code Source</h2>
		<p>The code use to make the image <a href="https://www.w3schools.com/howto/howto_js_slideshow.asp">slideshows</a>, <a href="https://www.w3schools.com/php/php_ajax_poll.asp">polls</a>, <a href="https://www.w3schools.com/php/php_ajax_livesearch.asp">searchbar</a> and <a href="https://www.w3schools.com/css/css_dropdowns.asp">dropdowns</a> have been customised from W3C examples.
	</main>
	<main-aside class="box">
		<p>If any other code or images on this website are found to be similar to another website's code or images are found somewhere else, please <a href="contactus.php">contact us</a> or email me at oshaw@students.mags.school.nz</p>
	</main-aside>
<?php include "bottombit.php"; ?>