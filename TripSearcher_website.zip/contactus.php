<?php include "topbit.php"; ?>
			<main class="box">
				<!-- contact us form made with google forms -->
				<h3>Contact Us</h3>
				<iframe src="https://docs.google.com/forms/d/e/1FAIpQLSfOoIkRMiPRK6-cdE0qMetzpR4cpP9xYROQOHHLDRBzbFf-mw/viewform?embedded=true" height="685"></iframe>
			</main>
			<main-aside class="box">
				<p>For more detailed feedback, contact me using my email oshaw@students.mags.school.nz.</p>
			</main-aside>
<?php include "bottombit.php"; ?>