<!DOCTYPE html>
<html lang = "en">
	<!-- website setup -->
	<head>
		<meta charset="utf-8">
		<meta name="description" content="Free Web tutorials">
 		<meta name="keywords" content="HTML,CSS,XML,JavaScript">
 		<meta name="author" content="Owen Shaw">
 		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<!-- link to css -->
		<link rel="stylesheet" href="css/tourism_style.css">
		<title>Tourism in NZ</title>
		<!-- link to font -->
		<link rel="preconnect" href="https://fonts.gstatic.com">
		<link href="https://fonts.googleapis.com/css2?family=Roboto&family=Roboto+Slab&display=swap" rel="stylesheet">
		<!-- searchbar javascript -->
		<script>
			function showResult(str) {
				if (str.length==0) {
					document.getElementById("livesearch").innerHTML="";
					document.getElementById("livesearch").style.border="0px";
					return;
				}
				var xmlhttp=new XMLHttpRequest();
				xmlhttp.onreadystatechange=function() {
					if (this.readyState==4 && this.status==200) {
						document.getElementById("livesearch").innerHTML=this.responseText;
						document.getElementById("livesearch").style.border="1px solid #A5ACB2";
					}
				}
				xmlhttp.open("GET","livesearch.php?q="+str,true);
				xmlhttp.send();
			}
		</script>
		
	</head>
	<body>
		<div class="wrapper">
			<header class="box">
				<!-- TripSearcher Logo and main header -->
				<img src="img/tourismNZlogo.png" class="round_img" width="100" height="100" alt="TripSearcher logo">
				<h1 class="vertically-centre">TripSearcher</h1>
			</header>
			 <header-aside class="box">
				 <!-- Searchbar -->
				 <form class="vertically-centre">
					<input type="text" size="30" onkeyup="showResult(this.value)" class="wide">
					<div id="livesearch"></div>
				 </form>
			</header-aside>
			<nav class="box">
				<!-- navigation bar -->
				<a class="dropbtn" href="index.php">Home</a> |
				<!-- first dropdown menu -->
				<div class="dropdown">
					<a class="dropbtn" href="#">Locations <span class="littlearrow">&#9660;</span></a>
					<div class="dropdown-content">
						<!-- second dropdown menus -->
  						<div class="dropdown2">
							<a class="dropbtn2" href="queenstown.php">Queenstown <span class="littlearrow">&#9660;</span></a>
							<div class="dropdown-content2">
								<a href="queenstown.php">General Information</a>
    							<a href="queenstownactivities.php">Things to do</a>
							</div>
						</div>
    					<div class="dropdown2">
							<a class="dropbtn2" href="rotorua.php">Rotorua  ‏‏‎ ‏‏‎ ‏‏‎ ‏‏‎ ‏‏‎ ‏‏‎ ‏‏‎ ‏‏‎ ‏‏‎<span class="littlearrow">&#9660;</span></a>
							<div class="dropdown-content2">
								<a href="rotorua.php">General Information</a>
    							<a href="rotoruaactivities.php">Things to do</a>
							</div>
						</div>
  					</div>
				</div>
				|
				<a class="dropbtn" href="aboutus.php">About Us</a> |
				<a class="dropbtn" href="contactus.php">Contact Us</a> 
			</nav>