<?php include "topbit.php"; ?>
	<main class="box">
		<!-- Queenstown activites general info. -->
		<h2>Queenstown Activities</h2>
		<p>Queenstown has many different activites for tourists to do, from skiing to going on a luge to walking, Queenstown has something for everyone.</p>
		<h3>Luge + gondola</h3>
		<!-- luge image -->
		<center><img src="img/luge.jpg" width="800" alt="Queenstown Luge Track"></center>
		<!-- luge + gondola info. -->
		<p>On a mountain right next to the town, there is a <a href="https://www.skyline.co.nz/en/queenstown/">gondola</a> that takes you up the mountain to a viewing spot where there is a cafe/restaurant, a luge track, and a mountain bike track that goes down the mountain. You can use the gondola to bring your pikes back up to the top of the mountain so you don't have to ride the pike up yourself, and the luge has chairlifts to bring you to the top of the luge tracks. </p>
		<h3>Skiing</h3>
		<!-- skiing image -->
		<center><img src="img/skiing.jpg" width="800" alt="skier skiing down a mountain"></center>
		<!-- skiing near Queenstown info. -->
		<p>Queenstown has 4 major ski fields within driving distance away from it, <a href="https://www.theremarkables.co.nz/">The Remarkables</a>, <a href="https://www.coronetpeak.co.nz/">Coronet Peak</a>, <a href="http://www.cardrona.com/">Cardrona</a>, and <a href="https://www.treblecone.com/">Treble Cone</a>. These ski fields/resorts allow skiers both new and experienced to enjoy themselves in the snow. </p>
		<h3>Milford Sound</h3>
		<!-- Milford Sound image -->
		<center><img src="img/milfordsound.jpg" width="800" alt="Milford Sound"></center>
		<!-- Milford Sound info. -->
		<p>Milford Sound, while a long drive away from Queenstown, is accessable from it if you spend a day or 2 driving there while doing other activities along the way. Milford Sound itself is a famous fiord with blue water surronded by mountains with snow capped tips in the winter and waterfalls running down the sides. You can get a <a href="https://www.milford-sound.co.nz/milford-sound-cruises/">cruise</a> to take a trip round the fiord and experience its beauty. </p>
	</main>
	<main-aside class="box">
		<!-- Link to general Queenstown info. and where to stay in Queenstown -->
		<p>For general information about Queenstown, look <a href="queenstown.php">here</a> <br>
		For places to stay at Queenstown, look <a href="https://www.queenstownnz.co.nz/accommodation/">here</a>.</p>
		<!-- Queenstown activites poll javascript -->
		<script>
			function getVote(int) {
				var xmlhttp=new XMLHttpRequest();
				xmlhttp.onreadystatechange=function() {
					if (this.readyState==4 && this.status==200) {
						document.getElementById("poll").innerHTML=this.responseText;
    				}
  				}
  				xmlhttp.open("GET","polls/queenstownactivitiesvote.php?vote="+int,true);
  				xmlhttp.send();
			}
		</script>
		<!-- Queenstown activites poll html -->
		<div id="poll">
			<h4>Do you recommend doing these activites?</h4>
			<form>
				<!-- yes input -->
				Yes: <input type="radio" name="vote" value="0" onclick="getVote(this.value)"><br>
				<!-- no input -->
				No: <input type="radio" name="vote" value="1" onclick="getVote(this.value)">
			</form>
		</div>
	</main-aside>
<?php include "bottombit.php"; ?>