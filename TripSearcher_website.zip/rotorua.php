<?php include "topbit.php"; ?>
	<main class="box">
		<h2>Rotorua</h2>
		<!-- Slideshow -->
		<div class="slideshow-container">

			<!-- First image in slideshow -->
			<div class="mySlides fade">
				<div class="numbertext">1 / 3</div>
				<img src="img/volcaniclake.jpg" style="width:100%" alt="Volcanic lake">
				<div class="text">Volcanic lake near Rotorua</div>
			</div>
			
			<!-- Second image in slideshow -->
			<div class="mySlides fade">
				<div class="numbertext">2 / 3</div>
				<img src="img/geyser.jpg" style="width:100%" alt="Geyser">
				<div class="text">Geyser near Rotorua</div>
			</div>
			
			<!-- Third image in slideshow -->
			<div class="mySlides fade">
				<div class="numbertext">3 / 3</div>
				<img src="img/laketarawera.jpg" style="width:100%" alt="Lake Tarawera">
				<div class="text">Lake Tarawera</div>
			</div>

			<!-- Next and previous buttons -->
			<a class="prev" onclick="plusSlides(-1)">&#10094;</a>
			<a class="next" onclick="plusSlides(1)">&#10095;</a>
		</div>
		<br>

		<!-- The dots at the bottom of the slideshow -->
		<div style="text-align:center">
			<span class="dot" onclick="currentSlide(1)"></span>
			<span class="dot" onclick="currentSlide(2)"></span>
			<span class="dot" onclick="currentSlide(3)"></span>
		</div>
		
		<!-- link to slideshow javascript -->
		<script src="slideshow.js"></script>
		
		<!-- Rotorua info. -->
		<p>Rotorua is a town in the North Island that is in a very volcanically active area. This means that the area has a lot of <a href="rotoruaactivities.php">activities</a>  to enjoy, such as walks around colourful lakes, watching geysers, and taking baths in mad pools. Because of the strong tourist presence there, there are also a lot of <a href="https://www.trivago.co.nz/rotorua-531940/hotel">places</a> to stay.<br>
		For more information on Rotorua, visit <a href="https://www.rotoruanz.com//">https://www.rotoruanz.com</a>.</p>
	</main>
	<main-aside class="box">
		<!-- link to Rotorua activites and where to stay in Rotorua -->
		<p>For activites to do in Rotorua, look <a href="rotoruaactivities.php">here</a><br>
		For places to stay in Rotorua, look <a href="https://www.trivago.co.nz/rotorua-531940/hotel">here</a></p>
		<!-- Rotorua poll javacript -->
		<script>
			function getVote(int) {
				var xmlhttp=new XMLHttpRequest();
				xmlhttp.onreadystatechange=function() {
					if (this.readyState==4 && this.status==200) {
						document.getElementById("poll").innerHTML=this.responseText;
    				}
  				}
  				xmlhttp.open("GET","polls/rotoruavote.php?vote="+int,true);
  				xmlhttp.send();
			}
		</script>
		<div id="poll">
			<!-- Rotorua poll html -->
			<h4>Do you recommend visiting this location?</h4>
			<form>
				<!-- yes input -->
				Yes: <input type="radio" name="vote" value="0" onclick="getVote(this.value)"><br>
				<!-- no input -->
				No: <input type="radio" name="vote" value="1" onclick="getVote(this.value)">
			</form>
		</div>
	</main-aside>
<?php include "bottombit.php"; ?>