			<!-- left side of footer -->
			<footer class="box">
				&copy; TripSearcher
			</footer>
			<!-- right side of footer -->
			<footer-aside class="box">
				<a href="sources.php">Sources</a>
			</footer-aside>
		</div>
	</body>
</html>