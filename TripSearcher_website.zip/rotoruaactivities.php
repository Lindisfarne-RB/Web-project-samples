<?php include "topbit.php"; ?>
	<main class="box">
		<!-- General info. about Rotorua activites -->
		<h2>Rotorua Activities</h2>
		<p>Rotorua has many different activites for tourists to do, from enjoying a mud spa to walking round a volcanic lake to learning about Maori culture, Rotorua has something for everyone.</p>
		<h3>Volcanic Air</h3>
		<!-- Volcanic Air image -->
		<center><img src="img/helicopter.jpg" width="800" alt="Volcanic Air helicopter"></center>
		<!-- Volcanic Air general info. -->
		<p>Take a trip in a helicopter and experience stunning views with <a href="https://www.volcanicair.co.nz/">Volcanic Air</a> as you fly over geothermal lakes and terrain.</p>
		<h3>Tour round geothermal areas</h3>\
		<!-- Geothermal lake image -->
		<center><img src="img/geothermal.jpg" width="800" alt="Geothermal lake"></center>
		<!-- Tours with Headfirst Travel general info. -->
		<p>Be taken on a tour round Rotorua's geothermal lakes with <a href="https://headfirsttravel.com/">Headfirst Travel</a>, and experience the wonders of bright blue, brown, green and even yellow geothermal lakes.</p>
	</main>
	<main-aside class="box">
		<!-- link to Rotorua general info. and where to stay in Rotorua -->
		<p>For general information about Rotorua, look <a href="rotorua.php">here</a> <br>
		For places to stay at Rotorua, look <a href="https://www.trivago.co.nz/rotorua-531940/hotel">here</a>.</p>
		<!-- Rotorua activites poll javascript -->
		<script>
			function getVote(int) {
				var xmlhttp=new XMLHttpRequest();
				xmlhttp.onreadystatechange=function() {
					if (this.readyState==4 && this.status==200) {
						document.getElementById("poll").innerHTML=this.responseText;
    				}
  				}
  				xmlhttp.open("GET","polls/rotoruaactivitiesvote.php?vote="+int,true);
  				xmlhttp.send();
			}
		</script>
		<div id="poll">
			<!-- Rotorua activites poll javascript -->
			<h4>Do you recommend doing these activites?</h4>
			<form>
				<!-- yes input -->
				Yes: <input type="radio" name="vote" value="0" onclick="getVote(this.value)"><br>
				<!-- no input -->
				No: <input type="radio" name="vote" value="1" onclick="getVote(this.value)">
			</form>
		</div>
	</main-aside>
<?php include "bottombit.php"; ?>