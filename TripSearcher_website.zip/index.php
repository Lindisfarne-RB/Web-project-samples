<?php include "topbit.php"; ?>
			<main class="box">
				<!-- Slideshow -->
				<div class="slideshow-container">

					<!-- First image in slideshow -->
					<div class="mySlides fade">
						<div class="numbertext">1 / 3</div>
						<img src="img/mountain1.jpg" style="width:100%" alt="snowy mountain">
					</div>
					
					<!-- Second image in slideshow -->
					<div class="mySlides fade">
						<div class="numbertext">2 / 3</div>
						<img src="img/nature1.jpg" style="width:100%" alt="side of mountain at Milford Sound">
					</div>
					
					<!-- Third image in slideshow -->
					<div class="mySlides fade">
						<div class="numbertext">3 / 3</div>
						<img src="img/hobbiton.jpg" style="width:100%" alt="hobbiton">
					</div>

					<!-- Next and previous buttons of slideshow -->
					<a class="prev" onclick="plusSlides(-1)">&#10094;</a>
					<a class="next" onclick="plusSlides(1)">&#10095;</a>
				</div>
				<br>

				<!-- The dots at the bottom of the slideshow -->
				<div style="text-align:center">
					<span class="dot" onclick="currentSlide(1)"></span>
					<span class="dot" onclick="currentSlide(2)"></span>
					<span class="dot" onclick="currentSlide(3)"></span>
				</div>
				
				<!-- Link to slideshow javascript -->
				<script src="slideshow.js"></script>
				
				<!-- Information on NZ -->
				<p>New Zealand is a country in the southern hemisphere made up of just over 4.5 million people (and over 30 million sheep). The country has many different places for tourists to visit and many different things to do, such as exploring <a href="rotoruaactivities.php">geothermal pools</a> in <a href="rotorua.php">rotorua</a>, or going <a href="queenstownactivities.php">skiing</a> in <a href="queenstown.php">queenstown.</a> There is plenty of things to do all around the country, and this website can be used to help you find out where to go, what to do there and where you can stay.</p>
			</main>
			<main-aside class="box">
				<!-- link to  contact us for if users want to ask any questions -->
				<p>If you have any questions about this website, you can contact us <a href="contactus.php">here</a>.</p>
			</main-aside>
<?php include "bottombit.php"; ?>