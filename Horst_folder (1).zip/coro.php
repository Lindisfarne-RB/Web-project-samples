<?php include "topbit.php"; ?> <?php #Includes the 'top bit' file - has the header and the nav bar.         ?>

<main>
	
	<div class="grid-container">
			 <div class="leftside">
		 
			
			 
				 <p>Sponsored By <a href="https://soundcloud.com/v3vox">V3VOX</a></p>
	
			
		</div>
		  <div class="grid-item">
			
			<h2 style="text-align:center;">The Coromandel Peninsula</h2>
			  <div class="allround hvrbox">
				  <a href="https://www.thecoromandel.com/">
				  <img class="allround" src="img/coro.jpg" width="300" height="200" alt="Akl" style="padding:5px">
				  </a>
			  </div>
			  <p>I did not have to make this page but here is a link to the official Coromandel Peninsula website. <br>Please click on the picture and enjoy reading through it!</p>
			</div>
		
			<div class="rightside">
		  
			  
			  
			  <p>Sponsored By <a href="https://soundcloud.com/v3vox">V3VOX</a></p>
			<script>
                function getVote(int) {
                  var xmlhttp=new XMLHttpRequest();
                  xmlhttp.onreadystatechange=function() {
                    if (this.readyState==4 && this.status==200) {
                      document.getElementById("poll").innerHTML=this.responseText;
                    }
                  }
                  xmlhttp.open("GET","poll_vote.php?vote="+int,true);
                  xmlhttp.send();
                }
                </script>
            
            <div id="poll">
                <h3>Was this page useful?</h3>
                <form>
                <p>Yes: <input type="radio" name="vote" value="0" onclick="getVote(this.value)"><br>
					No: <input type="radio" name="vote" value="1" onclick="getVote(this.value)"></p>
                </form>
            </div>
			
			</div>  
		</div>
	
	
</main>

<?php include "bottombit.php"; ?> <?php #Includes the 'bottom bit' php file - has footer             ?>