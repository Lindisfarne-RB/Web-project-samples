<?php include "topbit.php"; ?> <?php #Includes the 'top bit' file - has the header and the nav bar.         ?>

<main>
	
	<div class="grid-container">
			 <div class="leftside">
		 
			
			 
				 <p>Sponsored By <a href="https://soundcloud.com/v3vox">V3VOX</a></p>
	
			
		</div>
		  <div class="grid-item">
			
			<h2 style="text-align:center;">Contact Us!</h2>
			<iframe src="https://docs.google.com/forms/d/e/1FAIpQLSfu_9fXrYvqG_9UbGXMrCPi3tV1u2jA52SH1angWOT9mJOAAg/viewform?embedded=true" width="640" height="1015" frameborder="0" marginheight="0" marginwidth="0">Loading…</iframe>
			  
			
			  
			</div>
			<div class="rightside">
		  
			  
			  
			  <p>Sponsored By <a href="https://soundcloud.com/v3vox">V3VOX</a></p>
			
			
			</div>  
		</div>
	
	
</main>

<?php include "bottombit.php"; ?>  <?php #Includes the 'bottom bit' php file - has the footer             ?>