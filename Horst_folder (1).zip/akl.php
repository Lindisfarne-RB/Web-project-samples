<?php include "topbit.php"; ?> <?php #Includes the 'top bit' file - has the header and the nav bar.         ?>

<main>
	
	<div class="grid-container">
			 <div class="leftside">
		 
			
			 
				 <p>Sponsored By <a href="https://soundcloud.com/v3vox">V3VOX</a></p>
	
			
		</div>
		  <div class="grid-item">
			
			<h2 style="text-align:center;">AUCKLAND</h2>
			  <?php 
	
	#I made the text align to be centre because when I aligned left, it did not work well.
			  
			  ?>
			  <p style="text-align:center;">Auckland is the biggest and most well known city in New Zealand. Home to 1.5 million people,<br> spanning over 1,086 square kilometres, it really is 					New Zealand's powerhouse.</p>
			  <p style="text-align:center;">Where do we even begin with this city? That's right - the most famous building, the Sky Tower.<br> The Sky Tower is New Zealand's largest building, 				sitting at a height of 328 metres off the ground. <br><br> Near the middle, there is a restaurant where you can look over the city of Auckland and even further,<br> and you can 					also pay to bungy jump off the Sky Tower, or even just do a walk around it. Guided, of course.</p>
			  <p style="text-align:center;"><br><br>Auckland is filled with mountains. For example, there's Mt Eden which has a view <br>of basically the whole city, Mt Wellington, a mountain 				out east which also has a great view, and heaps more, <br> but the most important mountain is not just a mountain - it's an entire mountain range.</p>
			  <p style="text-align:center;">The Waitakere Ranges are located out west and comprises of over 27,000 hectares of land. Some of which is private land, <br>but other parts of it are public. This makes for some great walking tracks which is great if you want to take a step back<br> from the world and make yourself feel relaxed. </p>
			  
			  <div class="aklimages">
				  
				  <div class="allround hvrbox">
				  	<div class="skytower">
					  <a href="https://www.skycityauckland.co.nz">
					  <img class="hvrbox-layer_bottom" src="img/aklskytowerview.jpg" alt="sky" width="300" height="225">
						  <div class="hvrbox-layer_top">
							  <div class="hvrbox-text">Sky Tower</div>
						  </div>
						  </a>
				  
				  	</div>
				  </div>
				  <div class="allround hvrbox">
				  	<div class="waitakere">
					  <a href="https://www.newzealand.com/nz/feature/waitakere-ranges/">
					  <img class="hvrbox-layer_bottom" src="img/waitakere.jpg" alt="wai" width="300" height="225">
						  <div class="hvrbox-layer_top">
							  <div class="hvrbox-text">Waitakere Ranges</div>
						  </div>
						  </a>
				  
				  <?php
	
	#The links with the images take you to a website related to the image - with the Sky Tower I included the sky tower official website. Did this for Rotorua as well.
					  
			?>
				  	</div>
				  </div>
				  
				  <div class="allround hvrbox">
				  	<div class="missionbay">
					  <a href="https://www.missionbay.co.nz">
					  <img class="hvrbox-layer_bottom" src="img/missionbay.jpg" alt="mb" width="300" height="225">
						  <div class="hvrbox-layer_top">
							  <div class="hvrbox-text">Mission Bay</div>
						  </div>
					  	</a>
				  	</div>
				  </div>
				  <div class="allround hvrbox">
				  	<div class="museum">
					  <a href="https://www.aucklandmuseum.com">
					  <img class="hvrbox-layer_bottom" src="img/museum.jpg" alt="museum" width="300" height="225">
						  <div class="hvrbox-layer_top">
							  <div class="hvrbox-text">Auckland War Memorial Museum</div>
						  </div>
				  </a>
					  </div>
				  </div>
				  
			  </div>
			  <br><br><br><br><br><br><br><br><br> <?php #Same problem as the Home page here - go back to home page for why I have done this.       ?>
			  <p>These images will take you to the appropriate website of a few iconic Auckland places!</p>
			  
			  
			
			  
			</div>
			<div class="rightside">
		  
			  
			  
			  <p>Sponsored By <a href="https://soundcloud.com/v3vox">V3VOX</a></p>
				<script>
                function getVote(int) {
                  var xmlhttp=new XMLHttpRequest();
                  xmlhttp.onreadystatechange=function() {
                    if (this.readyState==4 && this.status==200) {
                      document.getElementById("poll").innerHTML=this.responseText;
                    }
                  }
                  xmlhttp.open("GET","poll_vote.php?vote="+int,true);
                  xmlhttp.send();
                }
                </script>
            
            <div id="poll">
                <h3>Was this page useful?</h3>
                <form>
                <p>Yes: <input type="radio" name="vote" value="0" onclick="getVote(this.value)"><br>
					No: <input type="radio" name="vote" value="1" onclick="getVote(this.value)"></p>
                </form>
            </div>
			
			
			</div>  
		</div>
	
	
</main>

<?php include "bottombit.php"; ?> <?php #Includes the 'bottom bit' php file - has the footer             ?>