<?php include "topbit.php"; ?>    <?php #Includes the 'top bit' file - has the header and the nav bar.         ?>
	<main>
		

		<div class="grid-container">
			 <div class="leftside">
		 
			
			 
				 <p>Sponsored By <a href="https://soundcloud.com/v3vox">V3VOX</a></p>
	
			
		</div>
		  <div class="grid-item">
			<?php 
			  #this is my code for the text above the images.
			  ?>
			<h2 style="text-align:center;">Kiwi Explorers - who are we?</h2>
			  <p style="text-align:center">The Kiwi Explorers organisation is a group of New Zealand experts in tourism who love and adore our beautiful country.</p>
				  
				  <p style="text-align:center">We think New Zealand has not only some amazing tourist attractions that everyone will enjoy,<br> but also some absolutely outstanding hidden gems that can't be found anywhere else. </p> 
			  <p style="text-align:center">We will do our best to convince you to think the same way as us - New Zealand is our priority!</p>
			
			
			  <?php 
			  #I have images that will take you to the specific page if you click on them.
			  ?>
			  
			  <div class="homeimages">
				  
				<div class="allround hvrbox">
					<div class="auckland">
					<a href="akl.php">
					<img src="img/akl.jpg" alt="akl" class="hvrbox-layer_bottom">
					<div class="hvrbox-layer_top">
						<div class="hvrbox-text">Auckland</div>
					</div>
					</a>
						 </div>
				</div>
				 
				  
				<div class="allround hvrbox">
					<div class="rotorua">
					<a href="rotorua.php">
					<img src="img/rotorua.jpg" alt="roto" class="hvrbox-layer_bottom" width="300" height="200">
					<div class="hvrbox-layer_top">
						<div class="hvrbox-text">Rotorua</div>
					</div>
					</a>
						 </div>
				</div>
				  
				  
				  
				<div class="allround hvrbox">
					<div class="qtown">
					<a href="qtown.php">
					<img src="img/queenstown.jpg" alt="qtown" class="hvrbox-layer_bottom"  height="200">
					<div class="hvrbox-layer_top">
						<div class="hvrbox-text">Queenstown</div>
					</div>
					</a>
						 </div>
				</div>
				  
				  <div class="allround hvrbox">
					<div class="coro">
					<a href="coro.php">
					<img src="img/coro.jpg" alt="qtown" class="hvrbox-layer_bottom">
					<div class="hvrbox-layer_top">
						<div class="hvrbox-text">Coromandel</div>
					</div>
					</a>
						 </div>
				  </div>
				  
			  </div>
			<br><br><br><br><br><br><br><br><br><br><br> <?php #Had to do many breaks here because if I take those out, the text below would be trapped in the images.    ?>
			  <p style="text-align:center;">Click on an image to see one of the many beautiful places in New Zealand!</p>
			  
			</div>
			<div class="rightside">
		  
			  
			  
			  <p>Sponsored By <a href="https://soundcloud.com/v3vox">V3VOX</a></p>
			
			
			</div>  
		</div>
		
	</main>
	

	
	<?php

# The HTML tag is trapped at the bottom of this page -- could not get it to move with the bottom bit file FYI. Same for all of the pages!

?>
	
	
	
	
	
	<?php include "bottombit.php"; ?>    <?php #Includes the 'bottom bit' php file - has the footer             ?>
	
	
	
	