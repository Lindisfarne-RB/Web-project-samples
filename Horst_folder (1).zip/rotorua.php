<?php include "topbit.php"; ?> <?php #Includes the 'top bit' file - has the header and the nav bar.         ?>

<main>
	
	<div class="grid-container">
			 <div class="leftside">
		 
			
			 
				 <p>Sponsored By <a href="https://soundcloud.com/v3vox">V3VOX</a></p>
	
			
		</div>
		  <div class="grid-item">
			
			<h2 style="text-align:center;">ROTORUA</h2>
			  
			  
			  <p>Rotorua is a city located near the middle of the North Island. Home to over 70,000 people, this is one of <br>the best tourist destinations in the country. </p><p>Rotorua has activities for anyone and everyone to enjoy. One of the best activities is the<br> Skyline Rotorua, which is accessible via a gondola ride, and up there are many different things:</p> <p> – a zipline, which is sure to get the adrenaline flowing in many people, <br>– my personal favourite, the luge, which is basically a cart and you race everyone to get to the bottom, <br> – a mountain bike park on site featuring world-class downhill courses, <br> – a nature trail for anyone not looking for anything too extreme, you get <br>to enjoy the serenity and many different native birds/trees.</p>
			  
			  <p>Rotorua is notable for its geothermal activity, with many geysers located around the area - many will<br> be hit by a weird smell for the people that haven't been to Rotorua in a while. <br><br>Hell's Gate is located in Tikitere, on the other side of the lake from Rotorua, this is a place <br>where you can watch this geothermal activity happen up close.</p>
			  <div class="rotoimages">
				  <?php #I made the same image code as Auckland and Main page here - rounded edges and a black shadow, for style.         ?>
				  <div class="allround hvrbox">
				  	<div class="gondola">
					  <a href="https://www.skyline.co.nz/en/rotorua/">
					  <img class="hvrbox-layer_bottom" src="img/skyline.jpg" alt="sky" width="300" height="225">
						  <div class="hvrbox-layer_top">
							  <div class="hvrbox-text">Skyline Rotorua</div>
						  </div>
						  </a>
				  
				  	</div>
				  </div>
				  <div class="allround hvrbox">
				  	<div class="geothermal">
					  <a href="https://www.hellsgate.co.nz/">
					  <img class="hvrbox-layer_bottom" src="img/thermal.jpg" alt="wai" width="300" height="225">
						  <div class="hvrbox-layer_top">
							  <div class="hvrbox-text">Hell's Gate</div>
						  </div>
						  </a>
				  
				  
				  	</div>
				  </div>
				  
				  <div class="allround hvrbox">
				  	<div class="maori">
					  <a href="https://www.mitai.co.nz/">
					  <img class="hvrbox-layer_bottom" src="img/maori.jpg" alt="mb" width="300" height="225">
						  <div class="hvrbox-layer_top">
							  <div class="hvrbox-text">Mitai Māori Village</div>
						  </div>
					  	</a>
				  	</div>
				  </div>
				  <div class="allround hvrbox">
				  	<div class="wharf">
					  <a href="https://www.rotoruanz.com/things-to-do/public-places-spaces/rotorua-lakefront">
					  <img class="hvrbox-layer_bottom" src="img/rotoruawharf.jpg" alt="museum" width="300" height="225">
						  <div class="hvrbox-layer_top">
							  <div class="hvrbox-text">Rotorua Lakefront</div>
						  </div>
				  </a>
					  </div>
				  </div>
				  
			  </div>
			  <br><br><br><br><br><br><br><br><br><br>
			  <p>These images will take you to the appropriate website of a few of Rotorua's world class places!</p>
			  
			
			  
			</div>
			  
			</div>
			<div class="rightside">
		  
			  <?php #Could not get this part to go with the grid - had to be stuck down the bottom.       ?>
			  
			  <p>Sponsored By <a href="https://soundcloud.com/v3vox">V3VOX</a></p>
				<script>
                function getVote(int) {
                  var xmlhttp=new XMLHttpRequest();
                  xmlhttp.onreadystatechange=function() {
                    if (this.readyState==4 && this.status==200) {
                      document.getElementById("poll").innerHTML=this.responseText;
                    }
                  }
                  xmlhttp.open("GET","poll_vote.php?vote="+int,true);
                  xmlhttp.send();
                }
                </script>
            
            <div id="poll">
                <h3>Was this page useful?</h3>
                <form>
                <p>Yes: <input type="radio" name="vote" value="0" onclick="getVote(this.value)"><br>
					No: <input type="radio" name="vote" value="1" onclick="getVote(this.value)"></p>
                </form>
            </div>
			
	
			 
		</div>
	
	
</main>

<?php include "bottombit.php"; ?><?php #Includes the 'bottom bit' php file - has the footer             ?>