<!DOCTYPE html>
<html>

<head>

        <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <meta name="description" content="Free Web tutorials">
    <meta name="keywords" content="HTML,CSS,XML,JavaScript">
    <meta name="author" content="Alex Horst">
    
    <title>Kiwi Explorers</title>
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Lato&family=Oxygen:wght@700&display=swap" rel="stylesheet">

    
    
    
    <!-- link to css goes here -->
    <link href="css/maincss.css" rel="stylesheet">
    
</head>
    
<body>
    <div class="wrapper">
    
		<header class="box">
		<img class="allround" src="img/nz1.jpg" width="225" height="150" alt="Nz" style="float:left;">
			<img class="allround" src="img/nz1.jpg" width="225" height="150" alt="Nz" style="float:right;">	
		<h1 style="font-size: 40px;">🇳🇿Kiwi Explorers🇳🇿</h1>
    	<p style="color:black;">“New Zealand Is Our Priority“</p>
		<?php 
			
			#I wanted a header with two images - one on each side. Have added a shade and rounded edges for style
			
			?>
			
			
		</header>
        
    </div>
	<nav class="box">
			
		
<?php 
		#My HTML code for the nav bar - links are all working
		?>
			<ul>
			 	 <li><a href="index.php">Home</a></li>
			  
			  <li class="dropdown">
				<a href="javascript:void(0)" class="dropbtn">Our Favourite Places</a>
				<div class="dropdown-content">
				  <a href="akl.php">Auckland</a>
				  <a href="rotorua.php">Rotorua</a>
					<a href="qtown.php">Queenstown</a>
				  <a href="coro.php">Coromandel</a>
					
				</div>
			  </li>
				<li><a href="contactus.php">Contact Us</a></li>
			</ul>
        
        </nav>
    