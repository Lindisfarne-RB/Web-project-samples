<?php include "topbit.php"; ?> <?php #Includes the 'top bit' file - has the header and the nav bar.         ?>

<main>
	
	<div class="grid-container">
			 <div class="leftside">
		 
			
			 
				 <p>Sponsored By <a href="https://soundcloud.com/v3vox">V3VOX</a></p>
	
			
		</div>
		  <div class="grid-item">
			
			<h2 style="text-align:center;">Queenstown</h2>
			  <a href="https://www.queenstownnz.co.nz/">
			  <img class="allround" src="img/queenstown.jpg" width="300" height="200" alt="Akl" style="padding:5px"></a> <?php #Goes to the official Queenstown website on click   ?>
			  <p style="text-align:center;">Queenstown is different from the rest. Possibly one of the most visited places in New Zealand by tourists, we can see<br> why. Nestled deep in the South Island, snowy mountains surrounding it, there are many, many things to do in this wonderful town. <br><br>Did not have to make this but click on the image to get a link to the official Queenstown website!</p>
			  
			
			  
			</div>
			<div class="rightside">
		  
			  
			  
			  <p>Sponsored By <a href="https://soundcloud.com/v3vox">V3VOX</a></p>
			<script>
                function getVote(int) {
                  var xmlhttp=new XMLHttpRequest();
                  xmlhttp.onreadystatechange=function() {
                    if (this.readyState==4 && this.status==200) {
                      document.getElementById("poll").innerHTML=this.responseText;
                    }
                  }
                  xmlhttp.open("GET","poll_vote.php?vote="+int,true);
                  xmlhttp.send();
                }
                </script>
            
            <div id="poll">
                <h3>Was this page useful?</h3>
                <form>
                <p>Yes: <input type="radio" name="vote" value="0" onclick="getVote(this.value)"><br>
					No: <input type="radio" name="vote" value="1" onclick="getVote(this.value)"></p>
                </form>
            </div>
			
			</div>  
		</div>
	
	
</main>

<?php include "bottombit.php"; ?>  <?php #Includes the 'bottom bit' php file - has the footer             ?>