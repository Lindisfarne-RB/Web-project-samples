<!-- call topbit code -->
<?php include "topbitlegit.php"?>

<!-- begin main division -->
        <main class="box">
            <img class="dev" src=images/meming.jpg height=750><!-- one off picture of the developer -->
        </main>

<!-- begin aside class -->

    <!-- basic details on developer -->
        <aside class="box">
       <p>Finn de Lange - 12KMA</p>
            <br>
        <p>Student, just vibing in Auckland.</p>
            <br>
        <p>Kia Kaha!</p>
            <br>
            <a href="webindex.php"><img src=images/ExploreNZlogo.png alt=logo height=240></a>
        </aside>

<!-- call bottombitlegit.php -->
<?php include "bottombitlegit.php"?>