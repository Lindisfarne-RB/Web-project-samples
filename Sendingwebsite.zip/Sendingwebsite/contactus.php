<!-- call topbit code -->
<?php include "topbitlegit.php"?>

<!-- begin main division -->
        <main class="box">
        <!-- google form for feedback -->
            <iframe src="https://docs.google.com/forms/d/e/1FAIpQLSekAiULdjJ9rjNP6zp95Ms_8OhhU2-Y9A08KwyoI8NJtD5-aw/viewform?embedded=true" width="640" height="923" frameborder="0" marginheight="0" marginwidth="0">Loading…</iframe>
        </main>

<!-- begin aside class -->
        <aside class="box">
    <!-- Use aside as a friendly welcome without using the main space-->
       <p>Welcome to the contact page!</p>
            <br>
        <p>Feel free to give us your ideas, on places you think everyone who visits New Zealand should know about.</p>
            <br>
        <p>Kia Ora!</p>
            <br>
            <!-- logo links to home page -->
            <a href="webindex.php"><img src=images/ExploreNZlogo.png alt=logo height=240></a>
        </aside>

        </div> <!-- closes wrapper division class -->

    </body>

</html>