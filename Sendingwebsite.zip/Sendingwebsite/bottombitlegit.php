<!-- begin footer section -->
        <footer class="box">
        <h2>&copy; ExploreNZ</h2>    
        </footer>

        </div> <!-- closes wrapper division class -->

    </body>

</html>

<!-- end of pages -->