
<?php include("head_nav.html"); ?>
		
		<div class ="box main"> 
			<h2> Celebrate Reading!</h2>
			<p>
				
				This page celebrates books and reading. 
				Please browse throsugh the various sections 
				for a brief preview of some of my favourite
				books.
			
			
			</p> 
			
			<p>
				
				All artwork used on this page is either 
				Public Domain (via Pixabay) or it is cover
				art from the book being reviewed.
			</p>
			
			<p>
				Accessing reading material has never been
				easier, either visit your local library to
				get free books or, if you have a device like 
				and Ipad / tablet, use the OverDrive Media app
				to download books from your library's 
				eCollection for free.
				
			</p>
			
			<p>
			Please use the side bar to search for your local library. 
				A <a href= "https://natlib.govt.nz/librarians/directory-of-new-zealand-libraries"> full list of libraries </a> in New Zealand can be found 
				at the preceding link.
			</p>
		
		</div>
		
	<div class ="box side"> 
		<h2> Libraries List</h2>
		
		<p>
			The lis of libraries below is based on the 
			information on the national libraries website.
		</p>
		
		<ul>
			
			<li>
				<a href = "https://www.aucklandlibraries.govt.nz/"> AuckLand </a> </li>
			<li>
				<a href = "https://my.christchurchcitylibraries.com/"> Christchurch </a></li>
			<li> 
				<a href = "https://www.hamiltonlibraries.co.nz/">Hamilton</a> </li>
			<li> 
				<a href = "https://codc-qldc.govt.nz/"> Otago </a> </li>
			<li>
				<a href = "https://www.wcl.govt.nz"> Wellington </a> </li>
		
		</ul>
		
		
		</div>

	<?php include("footer.html"); ?>
	
		<div class ="box footer"> CC GTT 2021 </div>
	
	</div>
	
</body>
</html>