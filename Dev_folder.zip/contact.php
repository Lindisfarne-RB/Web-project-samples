<?php include("head_nav.html"); ?>
	
		<div class ="box main"> 
		
		<iframe class = "contact" src="https://docs.google.com/forms/d/e/1FAIpQLSeHu1BlPWwBTI-ac9GkuCslN0NSJYKfSjImkLhoA1iK9V-r_A/viewform?embedded=true" height="500"></iframe>
	
		</div>
		
	<div class ="box side"> 
			<h2> Libraries List</h2>
		
		<p>
			The lis of libraries below is based on the 
			information on the national libraries website.
		</p>
		<ul>
			
			<li>
				<a href = "https://www.aucklandlibraries.govt.nz/"> AuckLand </a> </li>
			<li>
				<a href = "https://my.christchurchcitylibraries.com/"> Christchurch </a></li>
			<li> 
				<a href = "https://www.hamiltonlibraries.co.nz/">Hamilton</a> </li>
			<li> 
				<a href = "https://codc-qldc.govt.nz/"> Otago </a> </li>
			<li>
				<a href = "https://www.wcl.govt.nz"> Wellington </a> </li>
		
		</ul>
		
</div>

<?php include ("footer.html"); ?>

	
